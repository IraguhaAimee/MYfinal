package com.example.helpmeapp;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class shakeme implements SensorEventListener {

    // Minimum acceleration to consider as shake movement
    private static final int MIN_SHAKE_ACCELERATION = 5;

    // Minimum number of movements to consider as shake
    private static final int MIN_SHAKE_MOVEMENTS = 2;

    // Time between shake movements in milliseconds
    private static final int SHAKE_MOVEMENT_TIME_INTERVAL = 1000;

    private OnShakeListener mShakeListener;
    private long mShakeTimestamp;
    private int mShakeMovementCount;

    public void setOnShakeListener(OnShakeListener listener) {
        mShakeListener = listener;
    }

    public interface OnShakeListener {
        void onShake();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        float acceleration = (float) Math.sqrt(x * x + y * y + z * z) - SensorManager.GRAVITY_EARTH;

        if (acceleration > MIN_SHAKE_ACCELERATION) {
            long now = System.currentTimeMillis();

            if (mShakeTimestamp + SHAKE_MOVEMENT_TIME_INTERVAL > now) {
                return;
            }

            mShakeTimestamp = now;
            mShakeMovementCount++;

            if (mShakeMovementCount >= MIN_SHAKE_MOVEMENTS) {
                mShakeListener.onShake();
            }
        } else {
            mShakeMovementCount = 0;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Do nothing
    }
}

