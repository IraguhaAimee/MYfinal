package com.example.helpmeapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class precycler extends RecyclerView.Adapter <precycler.vieww> {
    @NonNull
    @Override
    public vieww onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View inflate = inflater.inflate(R.layout.prow, parent,false);
        return new vieww(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull vieww holder, int position) {
        if(nam.isEmpty()){
            Toast.makeText(context.getApplicationContext(), "nothing",Toast.LENGTH_SHORT).show();
        }
        else {
            holder.name.setText(String.valueOf(nam.get(position)));
            holder.number.setText(String.valueOf(numb.get(position)));

        }
    }

    @Override
    public int getItemCount() {

        return  id.size();
        //return cursor.getCount();
    }
    ArrayList<String > id,numb,nam;
    Cursor cursor;
    Context context;
public precycler(Context ct, ArrayList i, ArrayList n, ArrayList  nu){

    context=ct;
    id=i;
    nam=n;
    numb=nu;
}



    public class vieww extends RecyclerView.ViewHolder{
    TextView name,number;
    //Button delt;
    FloatingActionButton delt;
    MyDatabaseHelper dbmng;

        public vieww(@NonNull View itemView) {
            super(itemView);
            dbmng=new MyDatabaseHelper(context.getApplicationContext());
            name=itemView.findViewById(R.id.pname);
            number=itemView.findViewById(R.id.pnumb);
            delt=itemView.findViewById(R.id.dele);
            delt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //Toast.makeText(context.getApplicationContext(), number.getText().toString(), Toast.LENGTH_SHORT).show();
                    dbmng.del(number.getText().toString());
                    Intent intent=new Intent(context.getApplicationContext(),ontacts.class);
                    context.startActivity(intent);
                }
            });

        }
    }
}
